<?php

include_once 'db.php';

if(isset($_POST["maa"]))
{

	session_start();
	$id=$_SESSION['id'];

    $country= $_POST['country'];
    $hospital= $_POST['hospital'];
    $doctor=$_POST['doctor'];
    $date=$_POST['date'];
    $clinic= $_POST['clinic'];

    $_SESSION['hospital']=$hospital;

    //$_SESSION['date']=$date;


        $insert=mysqli_query($link,"INSERT INTO appointment Values('$country','$hospital','$doctor','$date','$clinic','$id')");
        ?>
        echo <script>window.onload=function() 
        {
            var R=(confirm("Your Appointment has been made."));

            if(R==true){
                location.href="exit.html";
            }
            else{

            }


        }</script>;
<?php


    }



?>


<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>World Global Hospital</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo-1.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo-1.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Pogo Slider CSS -->
    <link rel="stylesheet" href="css/pogo-slider.min.css">
	<!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <link rel="stylesheet" type="text/css" href="css/anasayfa.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body id="home" data-spy="scroll" data-target="#navbar-wd" data-offset="98">


	<!-- Start header -->
	<header class="top-header">
		<nav class="navbar header-nav navbar-expand-lg">
            <div class="container">
				<a class="navbar-brand" href="homePage.php"> <img src="images/logo-1.png" alt="image" width="20%" height="30%"> </a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">

				</button>
                <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
                    <ul class="navbar-nav">
                        <li><a class="nav-link active" href="#home">Home</a></li>
                        <li><a class="nav-link" href="#about">About Us</a></li>                        
						<li><a class="nav-link" href="#appointment">Appointment</a></li>
						<li><a class="nav-link" href="#contact">Contact</a></li>
						
						<li><a class="nav-link" href="user-settings.php"><img src="images/icons8_user.ico"></a></li>
                    </ul>
                </div>
            </div>
        </nav>
	</header>
	<!-- End header -->
	
	<!-- Start Banner -->
	<div class="ulockd-home-slider">
		<div class="container-fluid">
			<div class="row">
				<div class="pogoSlider" id="js-main-slider">

					<div class="pogoSlider-slide" data-transition="fade" data-duration="1500" style="background-color: grey;">
						<div class="lbox-caption pogoSlider-slide-element">
							<div class="lbox-details">
								<h1><img src="images/logo-1.png" width="14%"> Welcome to World Global Hospital</h1>
								<p> <font size="4"> Welcome to the World Global Hospital.
 									We provide 24/7 service in our hospitals all over the world. 
 									Our hospitals have well-trained doctors from all over the world. 
 									You are in good hands here. </font></p>
							</div>
						</div>
					</div>

					

					<div class="pogoSlider-slide" data-transition="fade"  style="background-color: grey;">
						<div class="lbox-caption pogoSlider-slide-element">
							<div class="lbox-details">
								<h1><img src="images/logo-1.png" width="14%"> Welcome to World Global Hospital</h1>
								<p> <font size="4"> Welcome to the World Global Hospital.
 									If you want to get information : </font></p>
 									<a href="#about" class="btn">About Us</a>
							</div>
						</div>
					</div>

				</div><!-- .pogoSlider -->
			</div>
		</div>
	</div>
	<!-- End Banner -->
	
	<!-- Start About us -->
	<div id="about" class="about-box">
		<div class="about-a1">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="title-box">
							<h2>About Us</h2>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12">
						<div class="row align-items-center about-main-info">
							<div class="col-lg-6 col-md-6 col-sm-12">
								<h2> Welcome to World Global Hospital</h2>
								<p><font size="4">The World Global Hospital was established in 1942 within the World Health Organization in order to provide health services all over the world.</font></p>
								<p><font size="4">Currently, there are more than 150 World Global Hospitals in 120 countries.</font></p>
								<p><font size="4">Our hospitals have well-trained doctors from all over the world.</font></p>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="about-m">
									<ul id="banner">
										<li>
											<img src="images/photo1.png" alt="">
										</li>
										<li>
											<img src="images/photo2.jpg" alt="">
										</li>
										<li>
											<img src="images/photo3.jpg" alt="">
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End About us -->
	
	<!-- Start Services -->
	
	
	<!-- Start Appointment -->
	<div id="appointment" class="appointment-main">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="title-box">
						<h2>Appointment</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6 col-md-6">
					<div class="well-block">
                        <div class="well-title">
                            <h2>Make an Appointment</h2>
                        </div>
                        <form action="" method="post">
                            <!-- Form start -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="country">Country</label>
                                        <select name="country" class="form-control">
                                        	<option value="Choose Country">Choose Country</option>
                                            <option value="Germany">Germany</option>
                                            <option value="Italy">Italy</option>
                                            <option value="France">France</option>
                                            <option value="Denmark">Denmark</option>
                                            <option value="Turkey">Turkey</option>
                                            <option value="Columbia">Columbia</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="hospital">Hospital</label>
                                        <select name="hospital" class="form-control">
                                        	<option value="Choose Hospital">Choose Hospital</option>
                                            <option value="Ankara WG Hospital">Ankara WG Hospital</option>
                                            <option value="Italy WG Hospital">Italy WG Hospital</option>
                                            <option value="France WG Hospital">France WG Hospital</option>
                                            <option value="WG Hospital">WG Hospital</option>
                                            <option value="Columbia WG Hospital">Columbia WG Hospital</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="date">Doctor</label>
                                        <select name="doctor" class="form-control">
                                        	<option value="Choose Doctor">Choose Doctor</option>
                                            <option value="Prof. Dr. Daner">Prof. Dr. Daner</option>
                                            <option value="Dr. Mehmet">Dr. Mehmet</option>
                                            <option value="Dr. Mahmud">Dr. Mahmud</option>
                                            <option value="Prof. Dr. Charles Xavier">Prof. Dr. Charles Xavier</option>
                                            <option value="Dr. Chin Jen Yon">Dr. Chin Jen Yon</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Select Basic -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="time">Date Time</label>
                                        <input type="date" name="date" class="form-control input-md" 
       											value="2021-04-17"
      								 			min="2021-05-24" max="2021-06-12">
                                    </div>
                                </div>
                                <!-- Select Basic -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label" for="appointmentfor">Clinic</label>
                                        <select name="clinic" class="form-control">
                                            <option value="Choose Clinic">Choose Clinic</option>
											<option value="Gynacology">Gynacology</option>
											<option value="Dermatologist">Dermatologist</option>
											<option value="Orthology">Orthology</option>
											<option value="Anesthesiology">Anesthesiology</option>
											<option value="Ayurvedic">Ayurvedic</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                      <input type="checkbox" name="confirm" 
										value="yes"> I confirm the appointment.</input>
										<br>
										<input type="checkbox" name="UDoHR" 
										value="yes"> I have read and accept the Universal Declaration of Human Rights.</input>
                                </div>
                            </div>
                                <!-- Bu
                                	tton -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button name="maa" class="new-btn-d br-2">Make An Appointment</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!-- form end -->
                    </div>
				</div>
				<div class="col-lg-6 col-md-6">
					<div class="well-block">
                        <div class="well-title">
                            <h2>Why Appointment with Us</h2>
                        </div>
                        <div class="feature-block">
                            <div class="feature feature-blurb-text">
                            	<br><br>
                                <h4 class="feature-title">24/7 Hours Available</h4>
                                <div class="feature-content">
                                    <p> <b> We provide 24/7 service in our hospitals all over the world. </b></p>
                                </div>
                            </div>
                            <br><br>
                            <div class="feature feature-blurb-text">
                                <h4 class="feature-title">Experienced Staff Available</h4>
                                <div class="feature-content">
                                    <p> <b>You are in good hands here. </b></p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Appointment -->
	
	
<div id="contact" class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="title-box">
						<h2>Contact Us</h2>
					</div>
				</div>
			</div>
			<div class="row">
				
				<div class="col-lg-12 col-xs-12">
				  <div class="contact-block">
					<form id="contactForm">
					  <div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required data-error="Please enter your name">
								<div class="help-block with-errors"></div>
							</div>                                 
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<input type="text" placeholder="Your Email" id="email" class="form-control" name="name" required data-error="Please enter your email">
								<div class="help-block with-errors"></div>
							</div> 
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="text" placeholder="Your number" id="number" class="form-control" name="number" required data-error="Please enter your number">
								<div class="help-block with-errors"></div>
							</div> 
						</div>
						<div class="col-md-12">
							<div class="form-group"> 
								<textarea class="form-control" id="message" placeholder="Your Message" rows="8" data-error="Write your message" required></textarea>
								<div class="help-block with-errors"></div>
							</div>
							<div class="submit-button text-center">
								<button class="btn btn-common" id="submit" type="submit">Send Message</button>
								<div id="msgSubmit" class="h3 text-center hidden"></div> 
								<div class="clearfix"></div> 
							</div>
						</div>
					  </div>            
					</form>
				  </div>
				</div>	
			</div>
		</div>
	</div>
	<!-- End Contact -->	



	
	<!-- Start Footer -->
	<footer class="footer-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="footer-company-name">All Rights Reserved. &copy; 2021 <a href="#">World Global Hospital</a> </p>
				</div>
			</div>
		</div>
	</footer>
	<!-- End Footer -->
	
	<a href="#" id="scroll-to-top" class="new-btn-d br-2"><i class="fa fa-angle-up"></i></a>

	<!-- ALL JS FILES -->
	<script src="js/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
	<script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.pogo-slider.min.js"></script> 
	<script src="js/slider-index.js"></script>
	<script src="js/smoothscroll.js"></script>
	<script src="js/TweenMax.min.js"></script>
	<script src="js/main.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
	<script src="js/isotope.min.js"></script>	
	<script src="js/images-loded.min.js"></script>	
    <script src="js/custom.js"></script>
</body>



</html>