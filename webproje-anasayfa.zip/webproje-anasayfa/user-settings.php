﻿<?php
include_once "db.php";

session_start();
$id=$_SESSION['id'];

$name="";
$surname="";
$email="";
$dateofbirth="";
$idUS="";
$gender="";


    $searchQuery="SELECT * FROM patient WHERE id=$id ";
    $searchResult=mysqli_query($link,$searchQuery);

    if($searchResult)
    {

        if (mysqli_num_rows($searchResult)) 
        {
            while ($row=mysqli_fetch_array($searchResult)) 
            {
                $name=$row["name"];
                $surname=$row["surname"];
                $email=$row["email"];
                $dateofbirth=$row["dateofbirth"];
                $idUS=$row["id"];
                $gender=$row["gender"];

            }
        }

    }
    else
    {
        echo "error.";
    }

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>World Global Hospital</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="user-settings/assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="user-settings/assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="user-settings/assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="user-settings/assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

   <link rel="shortcut icon" href="images/logo-1.png" type="image/x-icon">
   <link rel="apple-touch-icon" href="images/logo-1.png">
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">User Settings</a> 
            </div>
  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"><a href="index.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="user-settings/assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                     			


            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        <form method="post">

        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>User Settings</h2>   
                        <p class="text-muted" name="name"> Welcome <?php echo $name; ?> </p>
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="row">
                <div>           
			<div class="panel panel-back noti-box">
                <span>
                   
                </span>
                <div class="text-box" >
                    <p class="main-text">NAME</p>
                    <p class="text-muted" name="name"><?php echo $name; ?></p> 
                </div>
             </div>
		     </div>
                    <div>           
			<div class="panel panel-back noti-box">
                <span>
                    
                </span>
                <div class="text-box" >
                    <p class="main-text">SURNAME</p>
                    <p class="text-muted" name="surname"><?php echo $surname; ?></p>
                </div>
             </div>
		     </div>
                    <div >           
			<div class="panel panel-back noti-box">
                <span>
                    
                </span>
                <div class="text-box" >
                    <p class="main-text">E-MAIL</p>
                    <p class="text-muted" name="email"><?php echo $email; ?></p>
                </div>
             </div>
		     </div>
                    <div >           
			<div class="panel panel-back noti-box">
                <span >
                   
                </span>
                <div class="text-box" >
                    <p class="main-text">BIRTH DATE</p>
                    <p class="text-muted" name="dateofbirth"><?php echo $dateofbirth; ?></p>
                </div>

             </div>
		     </div>
             <div >           
            <div class="panel panel-back noti-box">
                <span>
                    
                </span>
                <div class="text-box" >
                    <p class="main-text">IDENTIFICATION NUMBER</p>
                    <p class="text-muted" name="id"><?php echo $id; ?></p>
                </div>
             </div>
             </div>

            <div >           
            <div class="panel panel-back noti-box">
                <span>
                    
                </span>
                <div class="text-box" >
                    <p class="main-text">GENDER</p>
                    <p class="text-muted" name="gender"><?php echo $gender; ?></p>
                </div>
             </div>
             </div>

			</div> 
                 <!-- /. ROW  -->
                 </form>
                <hr />                
                
                 <!-- /. ROW  -->
               
                        
             <!-- /. PAGE INNER  -->

     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
