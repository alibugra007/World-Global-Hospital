<!DOCTYPE html>
<html>
<head>
  <title>Sign Up</title>

  <link rel="shortcut icon" href="images/logo-1.png" type="image/x-icon">
  <link rel="apple-touch-icon" href="images/logo-1.png">


  <link rel="stylesheet" type="text/css" href="css/loginPage.css">
</head>
<body>

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> Sign Up </h2>

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="images/logo-1.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form method="post" action=""> 
      <input type="text" id="name" class="fadeIn second" name="name" placeholder="NAME" required>
      <input type="text" id="surname" class="fadeIn second" name="surname" placeholder="SURNAME" required>
      <input type="text" id="email" class="fadeIn second" name="email" placeholder="E-MAIL" required>
      <input type="date" id="start" class="fadeIn second" name="dateofbirth" 
                            value="2000-00-00"
                            min="1850-04-17" max="2021-04-30" required>
      <input type="text" id="id" class="fadeIn second" name="id" placeholder="IDENTIFICATION NUMBER" required>
      <input type="password" id="pw" style="background-color: #f6f6f6;
  border: none;
  color: #0d0d0d;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 5px;
  width: 85%;
  border: 2px solid #f6f6f6;
  -webkit-transition: all 0.5s ease-in-out;
  -moz-transition: all 0.5s ease-in-out;
  -ms-transition: all 0.5s ease-in-out;
  -o-transition: all 0.5s ease-in-out;
  transition: all 0.5s ease-in-out;
  -webkit-border-radius: 5px 5px 5px 5px;
  border-radius: 5px 5px 5px 5px;" name="pw" placeholder="PASSWORD" required><br><br>
      <input type="radio" name="gender" value="female"><label for="female">Female</label>
      <input type="radio" name="gender" value="male"><label for="male">Male</label><br><br>
      <input type="submit" name="submit" class="fadeIn fourth" value="Sign Up">
    </form>
    

    <!-- Remind Passowrd -->

  </div>
</div>


</body>

<?php

include_once 'db.php';

if(isset($_POST["submit"])){

    $name= $_POST['name'];
    $surname= $_POST['surname'];
    $email=$_POST['email'];
    $dateofbirth=$_POST['dateofbirth'];
    $id= $_POST['id'];
    $pw= $_POST['pw'];
    $gender= $_POST['gender'];


    $res=mysqli_query($link,"SELECT * FROM patient WHERE id= '$id' ");
    $res1=mysqli_num_rows($res);

    if($res1==1)
    {
        ?>
        echo <script>window.onload=function()
        {
            alert("Patient has already exist.");
        }</script>;
        <?php


    }
    else
    {

        $insert=mysqli_query($link,"INSERT INTO patient Values('$name','$surname','$email','$dateofbirth','$id','$pw','$gender')");
        ?>
        echo <script>window.onload=function() 
        {
            var R=(confirm("User Succesfully Registered."));

            if(R==true){
                location.href="index.php";
            }
            else{

            }


        }</script>;
<?php


    }

}

?>



</html>