
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>

    <link rel="shortcut icon" href="images/logo-1.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo-1.png">

  <link rel="stylesheet" type="text/css" href="css/loginPage.css">
</head>
<body>

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> Login </h2>

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="images/logo-1.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form method="post">
      <input type="text" id="id" class="fadeIn second" name="id" placeholder="IDENTIFICATION NUMBER">
      <input type="password" style="background-color: #f6f6f6;
  border: none;
  color: #0d0d0d;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 5px;
  width: 85%;
  border: 2px solid #f6f6f6;
  -webkit-transition: all 0.5s ease-in-out;
  -moz-transition: all 0.5s ease-in-out;
  -ms-transition: all 0.5s ease-in-out;
  -o-transition: all 0.5s ease-in-out;
  transition: all 0.5s ease-in-out;
  -webkit-border-radius: 5px 5px 5px 5px;
  border-radius: 5px 5px 5px 5px;" id="pw" class="fadeIn third" name="pw" placeholder="PASSWORD">
      <input type="submit" name="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
   
    <div id="formFooter">
      <a class="underlineHover" href="signUpPage.php">Haven't Signed Yet ?</a>
    </div>

  </div>
</div>


</body>

<?php

session_start();

include_once 'db.php';

if(isset($_POST["submit"]))
{

$id=$_POST["id"];
$pw=$_POST["pw"];

$res=mysqli_query($link,"SELECT * FROM patient Where id='$id' and pw='$pw' ");
$res1=mysqli_num_rows($res);


if($res1==1)
    {
        $_SESSION['id']=$id;
        ?>

        echo <script> window.onload=function()
        {
            alert("Succesfully Login In");
        }</script>; 
        <?php
        header("location: homePage.php");     //main php ye gidicez bunun sayesinde
    }
    else{
        ?>
        echo <script>window.onload=function()
        {
            alert("Login ERROR.");
        }</script>;
<?php
    }

}
?>



</html>