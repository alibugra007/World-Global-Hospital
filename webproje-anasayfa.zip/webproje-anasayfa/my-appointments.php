
<?php
include_once "db.php";

session_start();
$hospital=$_SESSION['hospital'];
//$date=$_SESSION['date'];

$dateofMAP="";
$hospitalMAP="";

    $searchQuery="SELECT * FROM appointment WHERE hospital=$hospital ";
    $searchResult=mysqli_query($link,$searchQuery);

    if($searchResult)
    {

        if (mysqli_num_rows($searchResult)) 
        {
            while ($row=mysqli_fetch_array($searchResult)) 
            {
                $dateofMAP=$row["datetime"];
                $hospitalMAP=$row["hospital"];

            }
        }

    }

?>


<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>World Global Hospital - My Appointments</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/logo-1.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/logo-1.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Pogo Slider CSS -->
    <link rel="stylesheet" href="css/pogo-slider.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <link rel="stylesheet" type="text/css" href="css/anasayfa.css">

    <link rel="stylesheet" type="text/css" href="css/my-appointments.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  

</head>


<body id="home" data-spy="scroll" data-target="#navbar-wd" data-offset="98">


    <!-- Start header -->
    <header class="top-header">
        <nav class="navbar header-nav navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="index.php"> <img src="images/logo-1.png" alt="image" width="20%" height="30%"> </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">

                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
                    <ul class="navbar-nav">
                        <li><a class="nav-link active" href="homePage.php">Home</a></li>
                        <li><a class="nav-link" href="my-appointments.php">My Appointments</a></li>
                        <li><a class="nav-link" href="user-settings.php"><img src="images/icons8_user.ico"></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->

            <div class="title-box">
                <h2>My Appointments</h2>
            </div>


    <div class="div1">
        <br>
        <h1 class="h">My Current Appointments</h1> 
        <ul class="ul1">
            <li><b name="hospitalMAP"><?php echo $dateofMAP; echo $hospitalMAP; ?></b></li>
            <li><b name="hospitalMAP"><?php echo $dateofMAP; echo $hospitalMAP; ?></b></li>
            <li><b name="hospitalMAP"><?php echo $dateofMAP; echo $hospitalMAP; ?></b></li>
            <li><b name="hospitalMAP"><?php echo $dateofMAP; echo $hospitalMAP; ?></b></li>
            <li><b name="hospitalMAP"><?php echo $dateofMAP; echo $hospitalMAP; ?></b></li>
        </ul>
    </div>


    <div class="div2">
        <br>
        <h1 class="h">My Previous Appointments</h1>
        <ul class="ul2">
            <li><b></b></li>
            <li><b></b></li>
            <li><b></b></li>
            <li><b></b></li>
        </ul>

    </div>

</body>


</html>