<!DOCTYPE html>
<html>
<head>
  <title>Change Password</title>

  <link rel="shortcut icon" href="images/logo-1.png" type="image/x-icon">
  <link rel="apple-touch-icon" href="images/logo-1.png">


  <link rel="stylesheet" type="text/css" href="css/loginPage.css">
</head>
<body>

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> Change Password </h2>

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="images/logo-1.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form action="index.php">
      <input type="text" id="nPW" class="fadeIn second" name="nPW" placeholder="NEW PASSWORD">
      <input type="submit" class="fadeIn fourth" value="CHANGE THE PASSWORD">

    </form>

    <!-- Remind Passowrd -->
    

  </div>
</div>


</body>
</html>