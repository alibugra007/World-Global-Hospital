<!DOCTYPE html>
<html>
<head>
  <title>Forgot Password</title>

  <link rel="shortcut icon" href="images/logo-1.png" type="image/x-icon">
  <link rel="apple-touch-icon" href="images/logo-1.png">


  <link rel="stylesheet" type="text/css" href="css/loginPage.css">
</head>
<body>

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> Forgot Password </h2>

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="images/logo-1.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form method="post">
      <input type="text" id="id" class="fadeIn second" name="id" placeholder="IDENTIFICATION NUMBER">
      <input type="text" id="email" class="fadeIn third" name="email" placeholder="E-MAIL">
      <input type="submit" name="submit" class="fadeIn fourth" value="Send Code">

      
    </form>

    <form method="post">
      <input type="text" id="code" class="fadeIn third" name="code" placeholder="CODE">
      <input type="submit" class="fadeIn fourth" value="Enter Code">
    </form>
    <!-- Remind Passowrd -->
    

  </div>
</div>


</body>

<?php

session_start();

include_once 'db.php';


if(isset($_POST["submit"]))
{

$id=$_POST["id"];
$email=$_POST["email"];

$res=mysqli_query($link,"SELECT * FROM patient Where id='$id' and email='$email' ");
$res1=mysqli_num_rows($res);


if($res1==1)
    {
        // burada bir şeyler var

        ?>

        echo <script> window.onload=function()
        {
            alert("Code Sent.");
        }</script>; 
        <?php
             //main php ye gidicez bunun sayesinde
    }
    else{
        ?>
        echo <script>window.onload=function()
        {
            alert("ID cannot be found.");
        }</script>;
<?php
    }

}
?>

</html>